rng default
t = linspace(-pi,pi,1000);
x = sin(t) + 0.25*rand(size(t));
[B,A]=butter(3,[49 51]/(1000/2),'bandpass');
y = filtfilt(B,A,x);
% y1 = filter(B,A,x);

subplot(2,1,1)
% plot([y y1])
plot(y)
title('Filtered Waveforms')
legend('Zero-phase Filtering','Conventional Filtering')

subplot(2,1,2)
plot(x)
title('Original Waveform')
